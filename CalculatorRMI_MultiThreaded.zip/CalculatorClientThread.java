import java.rmi.Naming;
import java.util.Scanner;

public class CalculatorClientThread extends Thread {
    private double a, b;
    private int operation;

    public CalculatorClientThread(double a, double b, int operation) {
        this.a = a;
        this.b = b;
        this.operation = operation;
    }

    public void run() {
        try {
            Calculator stub = (Calculator) Naming.lookup("rmi://localhost/CalculatorService");
            double result = 0;
            String op = "";

            switch (operation) {
                case 1:
                    result = stub.add(a, b);
                    op = "Addition";
                    break;
                case 2:
                    result = stub.subtract(a, b);
                    op = "Subtraction";
                    break;
                case 3:
                    result = stub.multiply(a, b);
                    op = "Multiplication";
                    break;
                case 4:
                    result = stub.divide(a, b);
                    op = "Division";
                    break;
                default:
                    System.out.println("Invalid operation.");
                    return;
            }

            System.out.println("[" + Thread.currentThread().getName() + "] " + op + " of " + a + " and " + b + " = " + result);

        } catch (Exception e) {
            System.out.println("[" + Thread.currentThread().getName() + "] Client error: " + e);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter number of clients to simulate: ");
        int n = scanner.nextInt();

        CalculatorClientThread[] clients = new CalculatorClientThread[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nClient " + (i + 1) + " Input:");

            System.out.print("Enter first number: ");
            double a = scanner.nextDouble();

            System.out.print("Enter second number: ");
            double b = scanner.nextDouble();

            System.out.println("Select operation:");
            System.out.println("1. Add\n2. Subtract\n3. Multiply\n4. Divide");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();

            clients[i] = new CalculatorClientThread(a, b, choice);
        }

        System.out.println("\nStarting all client threads...\n");

        for (int i = 0; i < n; i++) {
            clients[i].start();
        }

        for (int i = 0; i < n; i++) {
            try {
                clients[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        scanner.close();
        System.out.println("\nAll client operations completed.");
    }
}